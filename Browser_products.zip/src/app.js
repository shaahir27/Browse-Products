import express from "express";
import mysql from "mysql2/promise";
import dotenv from "dotenv";
import cors from "cors";

const app = express();

app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 30,
    queueLimit: 0
})


app.get("/api/products", async (req, res) => {

    try{

        const limit = req.query.limit ? parseInt(req.query.limit) : 20;

        const category = req.query.category;

        let snapshotTime = req.query.snapshotTime;

        const cursor = req.query.cursor;

        let rows;

        if(!snapshotTime){

            const [snapshotRows] = await pool.query(
                `
                SELECT MAX(created_at) 
                AS snapshot
                FROM products
                `
            );

            snapshotTime = snapshotRows[0].snapshot;

            if(category){
                [rows] = await pool.query(
                    `
                    SELECT * FROM products
                    WHERE category = ? AND created_at <= ?
                    ORDER BY created_at DESC, id DESC
                    LIMIT ?
                    `,

                    [category, snapshotTime, limit]
                )
            }
            else{
                [rows] = await pool.query(
                    `
                    SELECT * FROM products
                    WHERE created_at <= ?
                    ORDER BY created_at DESC, id DESC
                    LIMIT ?
                    `,

                    [snapshotTime, limit]
                )
            }

            let nextCursor = null;

            if(rows.length != 0){

                const created_at = rows[rows.length - 1].created_at;
                const id = rows[rows.length - 1].id;

                nextCursor = Buffer.from(
                    JSON.stringify({
                        created_at,
                        id
                    })
                ).toString("base64");
            }
            

            return res.json({
                products: rows,
                snapshotTime,
                nextCursor
            })
        }

        if(!cursor){
            return res.status(400).json({error: "Cursor is required"});
        }

        const decoded = JSON.parse(
            Buffer.from(
                cursor, 
            "base64").toString("utf-8"));

        const created_at = decoded.created_at;
        const id = decoded.id;

        if(category){
            [rows] = await pool.query(
                `
                SELECT * FROM products
                WHERE category = ? 
                AND created_at <= ? 
                    AND (
                        created_at < ? 
                        OR 
                        ( created_at = ? AND id < ? )
                    )
                ORDER BY created_at DESC, id DESC
                LIMIT ?
                `,
                
                [category, snapshotTime, created_at, created_at, id, limit]
            )
        }
        else{
            [rows] = await pool.query(
                `
                SELECT * FROM products
                WHERE created_at <= ?
                AND ( created_at < ?
                    OR 
                    (created_at = ? AND id < ?)
                )
                ORDER BY created_at DESC, id DESC
                LIMIT ?
                `,

                [snapshotTime, created_at, created_at, id, limit]
            )
        }

        let nextCursor = null

        if(rows.length !== 0){

            const next_created_at = rows[rows.length - 1].created_at;
            const next_id = rows[rows.length - 1].id;

            nextCursor = Buffer.from(
                JSON.stringify({
                    created_at: next_created_at,
                    id: next_id
                })
            ).toString("base64");

        }
        

        res.json({
            products: rows,
            snapshotTime,
            nextCursor
        })

    }
    catch(err){
        console.error(`Error: ${err}`);

        res.status(500).json({error: "Internal Server Error"});
    }
})


app.listen(3000, () => {
    console.log("=================================");
    console.log("Server running on port 3000");
    console.log("=================================");
});